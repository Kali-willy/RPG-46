#!/system/bin/sh
# =================================================================
# RPG-46 Gaming Mode Launcher
# Advanced Game Booster with Loading Animation
# =================================================================

clear

# Box drawing characters
TL="┌" TR="┐" BL="└" BR="┘"
H="─" V="│"
FILL="█" EMPTY="░"

print_centered() {
    text="$1"
    width=60
    padding=$(( (width - ${#text}) / 2 ))
    printf "%${padding}s%s\n" "" "$text"
}

draw_box() {
    width=60
    
    # Top border
    printf "$TL"
    i=0; while [ $i -lt $((width - 2)) ]; do printf "$H"; i=$((i + 1)); done
    printf "$TR\n"
    
    # Content lines
    for line in "$@"; do
        printf "$V %-$((width - 4))s $V\n" "$line"
    done
    
    # Bottom border
    printf "$BL"
    i=0; while [ $i -lt $((width - 2)) ]; do printf "$H"; i=$((i + 1)); done
    printf "$BR\n"
}

progress_bar() {
    percent=$1
    label="$2"
    width=50
    filled=$((percent * width / 100))
    
    printf "  ["
    i=0
    while [ $i -lt $width ]; do
        if [ $i -lt $filled ]; then
            printf "$FILL"
        else
            printf "$EMPTY"
        fi
        i=$((i + 1))
    done
    printf "] %3d%% %s\n" "$percent" "$label"
}

spinner() {
    msg="$1"
    delay="$2"
    chars="⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
    i=1
    while [ $i -le ${#chars} ]; do
        c=$(echo "$chars" | cut -c$i)
        printf "\r  $c $msg"
        sleep "$delay"
        i=$((i + 1))
    done
    printf "\r  ✓ $msg\n"
}

# ==================== HEADER ====================
echo ""
echo "  ╔═══════════════════════════════════════════════════════╗"
echo "  ║                                                       ║"
echo "  ║              ██████╗ ██████╗  ██████╗                ║"
echo "  ║              ██╔══██╗██╔══██╗██╔════╝                ║"
echo "  ║              ██████╔╝██████╔╝██║  ███╗               ║"
echo "  ║              ██╔══██╗██╔═══╝ ██║   ██║               ║"
echo "  ║              ██║  ██║██║     ╚██████╔╝               ║"
echo "  ║              ╚═╝  ╚═╝╚═╝      ╚═════╝                ║"
echo "  ║                                                       ║"
echo "  ║                    -= 46 =-                          ║"
echo "  ║            GAMING MODE OPTIMIZER                     ║"
echo "  ║                                                       ║"
echo "  ╚═══════════════════════════════════════════════════════╝"
echo ""
sleep 0.5

# ==================== SYSTEM INFO ====================
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │              SYSTEM INFORMATION                     │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""

spinner "Detecting CPU cores" 0.05
cores=$(grep -c ^processor /proc/cpuinfo 2>/dev/null)
[ -z "$cores" ] && cores=4
echo "    • CPU Cores: $cores"
sleep 0.1

spinner "Reading memory info" 0.05
if [ -r /proc/meminfo ]; then
    total_mem=$(awk '/MemTotal:/ {printf "%.1f", $2/1024/1024}' /proc/meminfo)
    echo "    • Total RAM: ${total_mem} GB"
else
    echo "    • Total RAM: Unknown"
fi
sleep 0.1

spinner "Checking Android version" 0.05
android_ver=$(getprop ro.build.version.release 2>/dev/null)
[ -z "$android_ver" ] && android_ver="Unknown"
echo "    • Android: $android_ver"
sleep 0.2

echo ""

# ==================== INITIALIZATION ====================
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │           INITIALIZING GAMING MODE                  │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""

sleep 0.3

# Stage 1: CPU Optimization
progress_bar 0 "CPU Optimization"
sleep 0.2
setprop debug.hwui.target_cpu_time_percent 85 2>/dev/null
progress_bar 25 "CPU Optimization"
sleep 0.2
setprop debug.hwui.use_hint_manager true 2>/dev/null
progress_bar 50 "CPU Optimization"
sleep 0.2
setprop debug.sf.enable_adpf_cpu_hint true 2>/dev/null
progress_bar 75 "CPU Optimization"
sleep 0.2
progress_bar 100 "CPU Optimization [DONE]"
echo ""
sleep 0.3

# Stage 2: GPU Acceleration
progress_bar 0 "GPU Acceleration"
sleep 0.2
setprop debug.hwui.renderer skiagl 2>/dev/null
setprop debug.renderengine.backend skiaglthreaded 2>/dev/null
progress_bar 30 "GPU Acceleration"
sleep 0.2
setprop debug.egl.hw 1 2>/dev/null
setprop debug.composition.type gpu 2>/dev/null
progress_bar 60 "GPU Acceleration"
sleep 0.2
setprop persist.sys.ui.hw 1 2>/dev/null
setprop ro.config.enable.hw_accel true 2>/dev/null
progress_bar 90 "GPU Acceleration"
sleep 0.2
progress_bar 100 "GPU Acceleration [DONE]"
echo ""
sleep 0.3

# Stage 3: Render Pipeline
progress_bar 0 "Render Pipeline"
sleep 0.2
setprop debug.sf.latch_unsignaled 1 2>/dev/null
progress_bar 40 "Render Pipeline"
sleep 0.2
setprop debug.choreographer.skipwarning 1 2>/dev/null
progress_bar 70 "Render Pipeline"
sleep 0.2
setprop debug.hwui.render_thread_count 4 2>/dev/null
progress_bar 100 "Render Pipeline [DONE]"
echo ""
sleep 0.3

# Stage 4: Memory & Thermal
progress_bar 0 "Memory & Thermal"
sleep 0.2
progress_bar 50 "Memory & Thermal"
sleep 0.2
progress_bar 100 "Memory & Thermal [DONE]"
echo ""
sleep 0.3

# ==================== SUCCESS MESSAGE ====================
clear
echo ""
echo "  ╔═══════════════════════════════════════════════════════╗"
echo "  ║                                                       ║"
echo "  ║                  ✓ SUCCESS ✓                         ║"
echo "  ║                                                       ║"
echo "  ║         RPG-46 GAMING MODE ACTIVATED!                ║"
echo "  ║                                                       ║"
echo "  ╚═══════════════════════════════════════════════════════╝"
echo ""
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │              OPTIMIZATION APPLIED                    │"
echo "  ├─────────────────────────────────────────────────────┤"
echo "  │  ✓ CPU Boost Enabled           (85%)                │"
echo "  │  ✓ GPU Hardware Acceleration   (Active)             │"
echo "  │  ✓ ADPF Performance Hints      (Enabled)            │"
echo "  │  ✓ Render Thread Optimization  (4 Threads)          │"
echo "  │  ✓ Frame Pacing Enhanced       (Active)             │"
echo "  │  ✓ Thermal Management          (Monitoring)         │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""
echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │              LAUNCHING GAME ENGINE                   │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""

sleep 1

# Spinner animation for launching
msg="Starting RPG-46 Gaming Service"
chars="⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
cycles=3
c=1
while [ $c -le $cycles ]; do
    i=1
    while [ $i -le ${#chars} ]; do
        char=$(echo "$chars" | cut -c$i)
        printf "\r  $char $msg..."
        sleep 0.08
        i=$((i + 1))
    done
    c=$((c + 1))
done
printf "\r  ✓ $msg [READY]\n\n"

sleep 0.5

# ==================== LAUNCH GAMING MODE ====================
GAMING_SCRIPT="/sdcard/RPG-46/R/P/G/-/4/6/gaming_mode.sh"

echo "  ┌─────────────────────────────────────────────────────┐"
echo "  │            EXECUTING GAMING MODE                     │"
echo "  └─────────────────────────────────────────────────────┘"
echo ""

if [ -f "$GAMING_SCRIPT" ]; then
    echo "  → Script found: $GAMING_SCRIPT"
    echo "  → Executing now..."
    echo ""
    sleep 0.5
    
    # Execute the gaming mode script
    sh "$GAMING_SCRIPT"
    
else
    echo "  ✗ ERROR: Gaming mode script not found!"
    echo "  → Expected location: $GAMING_SCRIPT"
    echo ""
    echo "  Please ensure the script exists at the correct path."
    echo ""
    exit 1
fi

# ==================== CLEANUP ====================
cleanup() {
    echo ""
    echo "  ┌─────────────────────────────────────────────────────┐"
    echo "  │          SHUTTING DOWN GAMING MODE                   │"
    echo "  └─────────────────────────────────────────────────────┘"
    echo ""
    setprop debug.hwui.target_cpu_time_percent 0 2>/dev/null
    setprop debug.hwui.render_thread_count 0 2>/dev/null
    echo "  ✓ Gaming optimizations disabled"
    echo "  ✓ System restored to normal mode"
    echo ""
    echo "  Thank you for using RPG-46!"
    echo ""
    exit 0
}

trap cleanup TERM INT HUP QUIT

# Keep running
wait